<?php 
    echo "Hello world";

    //Salvar esse codigo com o nome de variavel.php

    $inteiro = 10;

    $real = 5.52;

    $nome = "Nivaldo";

    $ativo = true;

    print "Numero inteiro";

    echo "<br>";

    print $inteiro;

    echo "<br>";

    echo "<b>Nime do aluno </b>".$nome;

    $frases =["Hoje é um dia Lindo","Hoje é um dia Feio","Hoje é um dia"];

    $indice = rand(0,2);

    echo "Frase Aleatoria " . $frases[$indice];


    //loteria.php

    echo "<br>";
    echo "<br>";

    $numeros_possiveis = [1,2,3,4,5,6,7,8,9,10,];

    shuffle($numeros_possiveis);

    echo "Primeiro Número Sorteado" . $numeros_possiveis[0] ."<br><br>";
    
    echo "Primeiro Número Sorteado" . $numeros_possiveis[1] ."<br><br>";
    
    echo "Primeiro Número Sorteado" . $numeros_possiveis[2] ."<br><br>";
    
    echo "Primeiro Número Sorteado" . $numeros_possiveis[3] ."<br><br>";
    
    echo "Primeiro Número Sorteado" . $numeros_possiveis[4] ."<br><br>";
    
    echo "Primeiro Número Sorteado" . $numeros_possiveis[5] ."<br><br>";
?>